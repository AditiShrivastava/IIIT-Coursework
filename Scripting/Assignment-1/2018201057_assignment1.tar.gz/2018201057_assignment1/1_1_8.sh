#!/bin/bash

grep -wo '^[^[:upper:]]\{5\}\|^[^[:upper:]]\{10\}' /usr/share/dict/words


