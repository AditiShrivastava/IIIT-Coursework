#!/bin/bash

grep -ic '^[aeiou]' /usr/share/dict/words

