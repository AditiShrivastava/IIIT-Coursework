#!/bin/bash

sed -nE "/^[A-Z]/p" /usr/share//dict/words
