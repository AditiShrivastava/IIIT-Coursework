#!/bin/bash

grep -Ew "([0-9a-f][0-9a-f]-){3}([0-9a-f][0-9a-f])"
