#!/bin/bash

sed '/^[aeiuo]/Id' address-book.csv
