#!/bin/bash

 grep 'India\|Africa' /usr/share/dict/words
