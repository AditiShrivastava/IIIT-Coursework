#!/bin/bash

grep '.\{20,\}' /usr/share/dict/words

