#!/bin/bash

sed 's/[[:punct:]]/\*/g' | sed 's/[0-9]/\?/g' address-book.csv 
