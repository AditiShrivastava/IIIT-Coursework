#!/bin/bash

sed -nE "/[[:punct:]]/Ip" /usr/share//dict/words


