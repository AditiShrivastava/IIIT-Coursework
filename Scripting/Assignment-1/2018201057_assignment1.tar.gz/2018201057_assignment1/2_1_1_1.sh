#!/bin/bash

sed -nE '/(india|Africa)/Ip' /usr/share/dict/words
