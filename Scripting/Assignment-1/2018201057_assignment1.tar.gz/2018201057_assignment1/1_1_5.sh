#!/bin/bash

grep '[[:punct:]]' /usr/share/dict/words
