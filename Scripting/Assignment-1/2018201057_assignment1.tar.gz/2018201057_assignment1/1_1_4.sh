#!/bin/bash

grep 'aa\+' /usr/share/dict/words
