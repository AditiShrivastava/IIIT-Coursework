#!/bin/bash

grep -i '^[aeiou].*[aeiou]$' /usr/share/dict/words

