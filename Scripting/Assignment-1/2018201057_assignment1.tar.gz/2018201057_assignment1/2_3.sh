#!/bin/bash

sed '/^[^#{}]/s/^/    /g'
