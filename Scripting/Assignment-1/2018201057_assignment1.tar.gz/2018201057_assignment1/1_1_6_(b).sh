#!/bin/bash

grep '[A-Z]$' /usr/share/dict/words
