#!/bin/bash

ls -l | grep -c '^d'

