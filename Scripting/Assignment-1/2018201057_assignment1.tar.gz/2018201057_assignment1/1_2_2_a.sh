#!/bin/bash

grep -w '[[:digit:]]\{3\}\.[[:digit:]]\{3\}\.[[:digit:]]\{3\}\.[[:digit:]]\{3\}'


