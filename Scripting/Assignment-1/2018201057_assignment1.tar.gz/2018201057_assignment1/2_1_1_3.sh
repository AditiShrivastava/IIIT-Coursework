#!/bin/bash

sed -nE '/(^[aeiou].*[aeiou]$|^[aeiou]$)/Ip' /usr/share//dict/words
