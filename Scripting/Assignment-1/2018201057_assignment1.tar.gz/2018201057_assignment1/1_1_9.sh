#!/bin/bash

grep '\(^.\).*\1$\|^.$' /usr/share/dict/words

